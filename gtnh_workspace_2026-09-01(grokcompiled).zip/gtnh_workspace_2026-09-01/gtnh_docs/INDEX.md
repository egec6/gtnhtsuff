# GTNH local source library
Mirrored Sept 1, 2026 for the 2.8.4 revenge run.
Canonical living notes stay in `/home/workdir/artifacts/gtnh_run_tracker.md`.
This folder is reference only — official wiki and quest book still win if they disagree.

## What we could and could not pull

Official wiki (wiki.gtnewhorizons.com / gtnh.miraheze.org) **blocks datacenter curl** (HTTP 403).
A full wiki dump is not sitting here. Steam-age pages were pulled through a browser tool and saved as extracts under `official/wiki/`.
Google Sheets **did** export as real `.xlsx`. GitHub raw files worked.

Live wiki remains: https://wiki.gtnewhorizons.com/

## Official

| File | What it is |
|---|---|
| `official/spreadsheets/GTNH_Official_Spreadsheet_2.8.xlsx` | Official game-data sheet (ores, tiers, etc.). Wiki: updated as of 2.8.0. Source ID `1EIZtJU5eBbnUlrg7fD_ZyIzsr9sn4l4no9ek6M_iSVM` |
| `official/spreadsheets/Mod_Support_Spreadsheet.xlsx` | Which mods are supported outside the pack / licenses |
| `official/github/GT-New-Horizons-Modpack_README.md` | Pack README + modlist pointer |
| `official/github/CONTRIBUTING.md` | Contribution guidelines |
| `official/github/changelog_2.8.3_to_2.8.4.md` | Official 2.8.4 changelog (bugfix release) |
| `official/github/gtnewhorizons_website.html` | Snapshot of gtnewhorizons.com |
| `official/wiki/*.md` | Browser extracts of current-tier wiki pages |

Official live links we did not freeze as files:
- Website https://www.gtnewhorizons.com/
- Wiki https://wiki.gtnewhorizons.com/
- Discord https://discord.gg/EXshrPV
- Downloads https://www.gtnewhorizons.com/downloads/
- GitHub org https://github.com/GTNewHorizons
- Modpack repo https://github.com/GTNewHorizons/GT-New-Horizons-Modpack
- Spreadsheet shortlink https://www.gtnewhorizons.com/spreadsheet

## Community (beloved / wiki-listed)

These are the sheets the official Quick Links page itself points at.

| File | What it is |
|---|---|
| `community/spreadsheets/Tips_and_Tricks_TheShadowofX_Threefold.xlsx` | **The** mid-game bible. Wiki-listed. Also exists as a partial site: https://crazedd0ge.github.io/gtnhnotes/ |
| `community/spreadsheets/Optimal_Material_Sources_Renewables.xlsx` | Where to farm materials later |
| `community/spreadsheets/Ore_Byproducts_Mixer_SpaceMining.xlsx` | Byproducts / mixer / space mining (numbers may lag) |
| `community/spreadsheets/Fuel_Cracking_Planet_Fluids.xlsx` | Fuel cracking, planet fluids |
| `community/spreadsheets/GTNH_Power_Planner_2.8.xlsx` | Power planner matching this pack generation |
| `community/spreadsheets/GTNH_Power_Planner_2.9.xlsx` | Newer planner (2.9 dailies — we are on 2.8.4) |
| `community/spreadsheets/Tinkers_Tool_Planner.xlsx` | TiC planner |
| `community/spreadsheets/Spice_of_Life_Tracker.xlsx` | Fox’s food/heart tracker (2.8) |
| `community/spreadsheets/Biome_Spreadsheet.xlsx` | Biomes / humidity / crop tags |
| `community/spreadsheets/Benzene_Infrastructure_Calculator.xlsx` | Later |
| `community/spreadsheets/Industrial_Farm_Calculator.xlsx` | Later |
| `community/spreadsheets/Cleanroom_Calculator.xlsx` | Later |
| `community/spreadsheets/Beamline_Calculator_2.9.xlsx` | Later |
| `community/spreadsheets/Large_Turbine_Calculator_2.7.xlsx` | Later |
| `community/spreadsheets/EoH_Calculator_2.8.xlsx` | Endgame |
| `community/spreadsheets/EoH_Calculator_2.6-2.7.xlsx` | Older EoH |
| `community/spreadsheets/Antimatter_Calculator.xlsx` | Endgame |
| `community/spreadsheets/Wand_Info.xlsx` | Thaumcraft |
| `community/spreadsheets/Sources_of_Essentia.xlsx` | Thaumcraft |
| `community/spreadsheets/Witches_Brews.xlsx` | Witchery |
| `community/spreadsheets/List_of_Ores_community.xlsx` | Extra ore list (tiny; official sheet is better) |
| `community/guides/Stone_Age_Guide.txt` | **Not** a current steam guide — Aura’s 2.1.2.3 *Thaum rush* doc (May 2024). Keep, don’t treat as 2.8.4 law |
| `community/guides/Thaumaturge_Essentia_Pipes.txt` | TC pipes |
| `community/guides/Stargate_Role_Conditions.txt` | Endgame roles |
| `community/guides/garden_of_grind_README.md` | Skyblock fork (not this save) |

Other respected live tools, not downloaded (apps, not documents):
- Online NEI / calculator https://shadowtheage.github.io/gtnh/
- GTNH Factory Planner https://gtnhplanner.com/
- Greginator https://divran.github.io/greginator/
- GTNH Flow https://github.com/OrderedSet86/gtnh-flow
- GTNHMultiblocks https://gtnhmultiblocks.pythonanywhere.com/

## How to use with this run

Priority for Steam Age right now:
1. Official wiki extracts in `official/wiki/` (Steam Age, Steam Machines, Water Tank, Tinkers, Beginner Tips)
2. Official spreadsheet ore tabs
3. Tips & Tricks sheet when something feels tribal-knowledge

Do **not** treat 2.9 planner numbers as law on 2.8.4.

Solar boilers: see Steam_Age + Steam_Machines extracts. They calcify; distilled water or wrench-replace resets. Silver is small-ore only in the overworld.
