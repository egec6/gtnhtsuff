# 🔧 Chunkloading Setup — GTNH (Server Utilities)

*Your boilers (and the future BBF farm) keep working even when you're 2,000 blocks away or logged off... well, far away at least. This is the "do it once, forget it forever" guide.*

---

## Step 0 — Close the game first
The config only applies on launch, and the in-game config screen only shows these options at the **main menu**, not the pause menu. Easiest path: quit to desktop, edit the file, relaunch.

## Step 1 — Find the config file
It lives in your **instance folder** (not the mods folder):

```
<your GTNH instance>/
└── serverutilities/
    └── serverutilities.cfg    ← this one
```

Launcher cheat-sheets:
- **Prism / MultiMC:** right-click the GTNH instance → "Minecraft folder" (or "Folder")
- **ATLauncher:** instance → "Open Folder" (or "Edit Mod" → open folder)
- **CurseForge app:** GTNH → "..." → "Open Folder"

## Step 2 — Flip the two flags
Open `serverutilities.cfg` in any text editor, Ctrl+F for `chunk`, and set **both** to `true`:

```
B:chunk_claiming=false   →  B:chunk_claiming=true
B:chunk_loading=false    →  B:chunk_loading=true
```

(They're in the `world` category. Claiming = protects chunks & is required; Loading = keeps them ticking.)

## Step 3 — (Optional) Raise the limits
Default per-player caps are modest. To raise them, in the **same cfg** find the `ranks` category and set `B:enabled=true`, then edit:

```
serverutilities/server/ranks.txt
```

Keys you care about:
| Key | Meaning | Max |
|---|---|---|
| `serverutilities.chunkloader.max_chunks` | chunkloaded chunks per player | 30,000 |
| `serverutilities.claims.max_chunks` | claimed (protected) chunks per player | 30,000 |
| `serverutilities.homes.max` | number of /home points | — |

For a boiler platform + BBF farm + tree farm, the defaults are probably fine at first; raise them when you go industrial.

## Step 4 — Restart, then use it in-game
1. Launch the game, load your world.
2. Open your **inventory** — there's a **map icon on the left side** of the screen.
3. In that chunk map:
   - **Left-click** a chunk → claim it
   - **Shift+click** → **claim AND chunkload** ← the money button
   - **Shift+right-click** → keep the claim, stop loading it
   - **Click-drag / shift+drag** → claim or load big rectangles; hold **CTRL** while dragging for large squares

## Step 5 — The JourneyMap overlay (the nice part)
Server Utilities integrates with JourneyMap: click the **three-figures button** on the map screen to show the claims overlay.
- **Double-click** an empty chunk = claim; **double-click** a claimed chunk = toggle chunkloading
- Press **DELETE** (default) while hovering = unclaim
- Opaque overlay = currently chunkloaded. Great for spotting stray loads from old mining trips and cleaning them up remotely.

## What to chunkload (recommendations)
- ✅ The **boiler platform** (so steam keeps flowing while you mine)
- ✅ Future **BBF farm** — the whole point: steel smelts while you're elsewhere
- ✅ Coke ovens / tree farm if you want charcoal accruing passively
- ⚠️ Be a little conservative anyway — every loaded chunk is simulated. A few dozen chunks is nothing; hundreds will tick down your FPS/TPS.
- ℹ️ Loaded machines still emit **pollution** — the BBF farm being chunkloaded doesn't exempt your lungs.

## Plan B (the devs' own cheat hatch)
Spawning in **Railcraft admin anchors** is explicitly considered acceptable by the pack devs (noted in quest book/discord). But the SU route above is cleaner, protected, and per-player — do that first.

---
*Config data lives per-world (`saves/<world>/serverutilities/...`), so it travels with your save, not your launcher.*
