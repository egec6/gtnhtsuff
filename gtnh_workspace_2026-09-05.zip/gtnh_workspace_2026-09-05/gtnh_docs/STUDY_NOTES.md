# Study notes — afternoon Sept 1 2026
Working through the local library. Live wiki / NEI still win. Not a machine vote.

## Official Small Ore (2.8.0) — Overworld
| Ore | Y | Amount/chunk |
|---|---|---|
| Diamond | 5–15 | 2 |
| Redstone | 5–25 | 8 |
| Lapis | 10–50 | 4 |
| Gold | 20–60 | 8 |
| Silver | 20–60 | **20** |
| Iron | 40–100 | 16 |
| Nickel | 80–150 | 8 |
| Copper | 60–180 | 32 |
| Zinc | 80–210 | 24 |
| Tin | 80–220 | 32 |
| Coal | 120–250 | 24 |

Small ores: fortune works. Harvest level one lower than the large block. Do not light JourneyMap veins.

## Official pipes (throughput numbers as printed)
Wood 350 K heat — steam is too hot. Tiny bronze 400, small bronze 800, normal 2400. Water can stay wood.

## Steam Machines extract
Small coal: 120 L/s steam, 16 kL water + steam tanks, 20 gibbl/s, charcoal 360 s at cap / 96 s heating.
HP coal: 300 L/s.
Simple solar: 120 L/s, 0 pollution. Calcification: Steam_Age says 3.5 h, Steam_Machines says 15 h then decay to 33%. Check tooltip in-world.
Alloy smelter peak 640 L/s on red alloy. Forge hammer 640 L/s, 1 s crush.
Macerator 80 L/s, 40 s. HP = half time, same total steam, double draw.
Steam Grinder: 285 bronze + 21 brick, 8 parallel, 125% speed, 62.5% steam. No byproducts.

## BBF
360 s coal / 240 s coke. 1 iron + 4 charcoal vs 1 iron + 2 coke. Wallshare. 8-pack = 180 firebricks. Calcite (lapis vein) + gypsum (mineral sand).

## Water
Humidity Water Tank ≠ the 4 Railcraft tanks already built. 25 L/s at 100% humidity + sky. 1 L water = 160 L steam so 25 L/s water = 4,000 L/s steam theoretical.

## Tips Steam Power thesis
Steam is a terrible *fuel* (2 L = 1 EU) and a good *machine bus* early because steam machines don’t rain-explode. Use it because the age requires it and because steam multis stay relevant longer than the boilers look.

## Circuits (steam slice)
Hammer plates 3→2. Batch wires/foils. Coin shop ok. Electronic Circuits stay painful until LV wiremill / assembler.

## Creosote
Torches, vanilla furnace 32 items/bucket, later lubricant / semi-fluid. Not for small coal boilers.

## Spice
50 shanks / extra heart. Healing Axe still the early path.

## Pack version
2.8.4 = bugfix on 2.8.x (EFR, Backhand, BogoSorter already in). Open-to-LAN warned.

## Conflicts to resolve in-game
Solar calcification 3.5 h vs 15 h.
Do not treat Aura Stone Age Guide (2.1.2 Thaum rush) as this save.
