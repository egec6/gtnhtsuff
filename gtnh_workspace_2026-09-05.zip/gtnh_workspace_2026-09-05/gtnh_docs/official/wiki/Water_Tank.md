# Water Tank (wiki extract)
Source: https://wiki.gtnewhorizons.com/wiki/Water_Tank
Pulled Sept 1, 2026.

Stone-tier Railcraft multiblock. Passive water from air humidity.
100% humidity + sky = **25 L/s**. No sky or snow: ×0.5. Rain: ×3. Stacks.
Capacity **400,000 L**. Auto-output any side except top, max 800 L/s.
Top is input-only. Boilers touching the tank fill one at a time.
Cannot wallshare. 3×3×3 hollow, 26 siding blocks.
Early recipe (iron rods + file): 130 planks, 52 iron, 26 sticky resin.
Not flammable despite looking wooden.

Water L/s = 25 × humidity × modifiers.

| Humidity | Water L/s | Steam equiv | Small coal | Large coal | Simple solar | Adv solar |
|---|---|---|---|---|---|---|
| 100% | 25.0 | 4,000 | 33.3 | 13.3 | 33.3 | 11.1 |
| 90% | 22.5 | 3,600 | 30.0 | 12.0 | 30.0 | 10.0 |
| 80% | 20.0 | 3,200 | 26.7 | 10.6 | 26.7 | 8.9 |
| 70% | 17.5 | 2,800 | 23.3 | 9.3 | 23.3 | 7.8 |
| 60% | 15.0 | 2,400 | 20.0 | 8.0 | 20.0 | 6.7 |
| 50% | 12.5 | 2,000 | 16.7 | 6.6 | 16.7 | 5.6 |
| 40% | 10.0 | 1,600 | 13.3 | 5.3 | 13.3 | 4.4 |
| 30% | 7.5 | 1,200 | 10.0 | 4.0 | 10.0 | 3.3 |
| 20% | 5.0 | 800 | 6.7 | 2.6 | 6.7 | 2.2 |
| 10% | 2.5 | 400 | 3.3 | 1.3 | 3.3 | 1.1 |

Small coal = 120 L/s steam. Large = 300. Simple solar = 120. Adv solar = 360.
1 L water → 160 L steam.
This run already has 4 Railcraft tanks (resin+iron), not this humidity tank — different structure. Don't mix the two in notes.
