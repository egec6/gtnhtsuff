# Tinkers Tools (wiki extract, early-game focus)
Source: https://wiki.gtnewhorizons.com/wiki/Tinkers_Tools
Pulled Sept 1, 2026.

NEI Tool Materials tab shows **boosted** mining level.
Smeltery / extruder recipes show **unboosted** (one lower).
New head or replaced head starts one level down until Mining XP hits **Boosted**.

## Mining levels (boosted names)

| Level | Block tier | Notable materials (boosted) |
|---|---|---|
| 00 | Stone | Netherrack, paper, magical wood |
| 01 | Copper | Flint, bone |
| 02 | Iron | Copper |
| 03 | Tin | Iron, thaumium |
| 04 | Redstone | Bronze |
| 05 | Obsidian | Steel, damascus steel, vanadiumsteel, energetic alloy |
| 06 | Ardite | Obzinite, shadow metal, manasteel, unstable, vibrant alloy |
| 07 | Cobalt | Ardite, infinity, oriharukon |
| 08 | Manyullyn | Cobalt, neutronium |
| 09+ | — | Manyullyn, bedrockium, draconium, ichorium, gaia… |

Diamond ore wants **04-Redstone**. GT iron pick is **03-Tin**. Bronze head unboosted = 03, boosted = 04.

## Instant mining-level items (no modifier slot)
Zombie head +1, skeleton skull +2, creeper head +4, wither skull +7, nether star +8.
Fully repaired tools only. Cannot apply if already Boosted.

## Steam-age pick heads (NEI boosted numbers)

| Head | Durability | Speed | Mining level | Trait |
|---|---|---|---|---|
| Flint | 113 | 4.00 | 01-Copper | — |
| Iron | 188 | 6.00 | 03-Tin | Reinforced I |
| Bronze | 285 | 6.50 | 04-Redstone | Reinforced I |
| Steel | 300 | 7.00 | 05-Obsidian | Reinforced II |

Diamond *modifier* is a poor slot this early (haste/lapis better). Catch-22 if you need diamonds to mine diamonds.

This run (Sept 1 2026): bronze head + creeper head mined the diamond vein.
