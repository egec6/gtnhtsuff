# Beginner Tips (wiki extract, condensed)
Source: https://wiki.gtnewhorizons.com/wiki/Beginner_Tips
Pulled Sept 1, 2026.

- Quest book first. Read it. Average clear: ~1600h team / ~2500h experienced solo.
- Latest **stable**. Dev/beta/RC are test builds.
- Prism + modern Java recommended. Avoid CurseForge launcher.
- World type: Realistic Alpha only or ore gen breaks.
- Waypoint everything (JourneyMap).
- Villages, stone circles (witchery), zinc gravel, rubber trees, clay, gravel/flint, silverwood, slime islands, roguelike dungeons, Pam gardens, meteors.
- Tainted Land spreads. Don't build next to it early.
- Spice of Life: variety or diminishing returns. Gardens → Healing Axe quest.
- TiC: mining XP vs tool XP. Repair before swapping parts. Poor tools level faster.
- NEI can lie about vanilla ingredient counts in machines.
- ServerUtilities chunkloading is off by default (this run already enabled it).
- Cover GT machines from rain or they explode.
- Plan layouts. Don't dump water into a hot dry boiler.
