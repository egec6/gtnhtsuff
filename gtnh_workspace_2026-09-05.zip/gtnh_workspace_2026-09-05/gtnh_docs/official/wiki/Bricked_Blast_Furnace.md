# Bricked Blast Furnace (wiki extract)
Source: https://wiki.gtnewhorizons.com/wiki/Bricked_Blast_Furnace
Pulled Sept 1, 2026.

Controller + firebrick shell, hollow interior, no buses. Items in/out of controller. Formed when a recipe starts (lights + smoke).

One BBF + firebricks costs: 144 clay dust, 72 gypsum, 72 calcite, 36 stone dust, 36 quartz sand, 28 iron plates.
Gypsum → mineral sand veins. Calcite → lapis veins.
32 firebricks + air interior + top center air. Controller front center, 2nd layer.

Steel: 360 s with coal/charcoal, **240 s with coke**.
Compressed fuel: 10 ingots per craft instead of 9.

Basic: 1 iron + 2 coal coke = 1 steel (240 s)
1 iron + 4 coal/charcoal = 1 steel (360 s)

Wallshare sides. 1 BBF = 36 firebricks. 2 = 60 (+24). 4 = 100. 8 = 180.
This run planned 8–10 wall-shared. Firebrick hunt is calcite + gypsum now.
