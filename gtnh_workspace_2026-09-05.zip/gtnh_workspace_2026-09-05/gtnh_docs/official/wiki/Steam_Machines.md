# Steam Machines (wiki extract)
Source: https://wiki.gtnewhorizons.com/wiki/Steam_Machines
Pulled Sept 1, 2026. Live page wins.

## Steam Boilers (singleblock)

GUI: fuel bottom-right, ash top-right, cells top-left / bottom-left. Heat gauge right, water center, steam left.

HEAT 20°C → 500°C or 1000°C. Heat up and cool down every few ticks. Max heat = less fuel. Portable scanner shows exact heat.

WATER in any side except top. Steam at 1:160 if heat ≥ 100°C.
**ADDING WATER TO A HOT DRY BOILER EXPLODES IT.** Break/replace to reset heat if it ran dry.

STEAM pushes to adjacent tanks/pipes on any side except front or bottom. No steam if T < 100°C or no water. Safe to back up; vents 25% when tank full. Steam tank size = water tank size.

| Type | Max heat | Heat up | Cool down | Water tank | Water in | Steam tank | Steam out | Pollution |
|---|---|---|---|---|---|---|---|---|
| Small Coal Boiler | 500°C | +1°C / 12 t | −1°C / 45 t | 16,000 L | 0.75 L/s | 16,000 L | **120 L/s** | 20 gibbl/s |
| Large Coal Boiler | 1,000°C | +1°C / 12 t | −1°C / 40 t | 32,000 L | 1.88 L/s | 32,000 L | **300 L/s** | 30 gibbl/s |
| Simple Solar Boiler | 500°C | +5°C / 12 t | −1°C / 9 t | 16,000 L | 0.75 L/s | 16,000 L | **120 L/s** | 0 |
| Advanced Solar Boiler | 500°C | +5°C / 12 t | −1°C / 15 t | 32,000 L | 2.25 L/s | 32,000 L | **360 L/s** | 0 |
| Reinforced Lava Boiler | 1,000°C | +1°C / 12 t | −1°C / 20 t | 32,000 L | 3.75 L/s | 32,000 L | **600 L/s** | 20 gibbl/s |
| Advanced Boiler LV | 1,250°C | +1°C / 10 t | −1°C / 40 t | 32,000 L | 4.69 L/s | 64,000 L | 750 L/s | 35 |
| Advanced Boiler MV | 1,500°C | +1°C / 10 t | −1°C / 40 t | 48,000 L | 9.38 L/s | 96,000 L | 1,500 L/s | 50 |
| Advanced Boiler HV | 1,750°C | +1°C / 10 t | −1°C / 40 t | 64,000 L | 14.1 L/s | 128,000 L | 2,250 L/s | 65 |

Coal boilers burn coal / charcoal / coke / dusts / cactus coke — not logs. Fuel ticks while heating; at cap, charcoal lasts 360 s on the small (96 s while heating).

### Solar calcification (this page)
Need sky. Pipes and semi-transparent blocks do **not** block sky. Calcify after **15 hours**, steam/water drop linearly to **33%** over the next 15 hours. Fix: wrench-break and replace, or use distilled water.
Silver early: small silver ore, 20 per chunk, y=20–60. Fortune / lapis on TiC pick recommended.
This disagrees with Steam_Age.md's "3.5 hours" figure. Check live wiki / in-game tooltip before trusting either.

Lava boiler: 3 L lava per 1°C while heating. Highest steam of steam-age singleblocks. Lava supply is the problem.

## Steam machines
Consume steam, must vent at end of recipe. Blocked vent = halt. Rotate vent with wrench.
(Rest of machine list on live wiki.)
