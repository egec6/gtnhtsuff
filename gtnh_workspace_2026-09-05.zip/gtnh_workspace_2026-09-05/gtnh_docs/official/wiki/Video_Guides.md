# Video Guides (wiki catalog)
Source: https://wiki.gtnewhorizons.com/wiki/Video_Guides
Not downloaded — videos stay on YouTube. Catalog only.

Relevant now / soon:
- Installing and Migrating — Poblin
- NEI — AdityaG
- Electricity — Regian
- Ore Processing — HamCorp (EV+ AE2 focused; ideas travel backward)
- Thaumcraft — Three, Ducked

Later: bees, reactors, water line, assembly line, EoH, Stargate.
Playthroughs not on this page: Threefold is the Tips sheet author; his LP is the unofficial companion to that spreadsheet.
