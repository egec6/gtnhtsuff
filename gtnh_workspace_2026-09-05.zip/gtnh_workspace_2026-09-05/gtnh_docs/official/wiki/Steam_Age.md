# Steam Age (wiki extract)
Source: https://wiki.gtnewhorizons.com/wiki/Steam_Age
Pulled Sept 1, 2026 via browser tool. Miraheze blocks raw dump from this environment.
Live page wins if this extract is incomplete.

The Steam Age is the second technological age, unlocked once you craft a Coal Boiler and complete the Stone Age. Goal of the era: first Electronic Circuit → Steam Turbine → LV.

## Goals
- Boilers
- Steam Machines
- Bricked Blast Furnace
- Nether

## Steam
Machines powered by steam from boilers (heat + water). Rate: **2 L steam = 1 EU**.

Do **not** use wooden pipes for steam — leak, explode, fire. Wooden pipes are fine for water. Steam wants metal pipes (bronze). Uncovered steam pipes and machine vents deal contact damage.

Units: 1 mB = 1 L. 1 bucket = 1000 L. 20 ticks/s. Example: 6 L/t × 20 = 120 L/s.

## Boilers
Convert water to steam at **1 L water = 160 L steam**. Need steady water (Water Tank) or they explode.
**If a boiler runs dry while hot, do not add water.** Adding water to a dry heated boiler explodes it and nearby machines.

### Coal Boilers
Accepts all kinds of coal as fuel (not compressed blocks). Small: **6 L/t = 120 L/s**, 20 pollution/s. Charcoal at full heat: **360 s**. While heating: **96 s**.
High Pressure Coal Boiler: fuel twice as fast, **15 L/t = 300 L/s**, 30 pollution/s.

### Solar Boilers
No fuel. Need unobstructed sky. Up to **6 L/t = 120 L/s**. OK under glass / non-solid. Not under solids or water.
This page says output diminishes after **more than 3.5 hours real time**. Wrench-replace to reset, or use distilled water (later).
Steam exits the marked square side only (default back); rotate with wrench.
High Pressure Solar: **18 L/t = 360 L/s**.

See also Steam_Machines.md — that page says calcification after **15 hours** down to 33% over the next 15. Check live wiki / NEI if these disagree.

### High Pressure Lava Boiler
Most efficient singleblock. Lava fuel. **30 L/t = 600 L/s**, 20 pollution/s. One lava bucket ≈ 200,000 L steam at full heat. Costs **15 steel**. Early lava logistics are the pain. Seared tank carries 4 buckets/slot.

### Railcraft Boilers
Multiblock, solid or liquid fuel, huge steam if fed. Reasonable if you stay on steam into LV.

## Steam Machines
Need: valid inputs, output space, enough steam, unobstructed exhaust vent.

Faces:
- Steam in: any side except front
- Items in/out: any side except front (hopper etc.)
- Exhaust: grey square must face air. Wrench to rotate.

High Pressure singleblocks: half recipe time, same total steam, **double draw**.
Multiblock variants process 8 recipes, 125% speed, 65% steam, **void outputs if steam dies mid-craft**. Bronze or steel frames. Steel multis act like HP. Wiki: do not steel-multi before EBF in late LV.

### Alloy Smelter
Alloying (bronze 4 from 3 Cu + 1 Sn) and molding (rubber sheets). Demanding recipes (red alloy) up to **32 L/t = 640 L/s**. Buffer + pause, or more boilers. Multiblock: Steam Fuser (lasts toward EV).

### Compressor
Low steam (~4 L/t / 80 L/s) but slow. Priority later: Steam Squasher multi.

### Extractor
Resin → raw rubber dust. Low steam, slow. HP upgrade matters when rubber demand grows.

(Page continues on live wiki: furnace, macerator, forge hammer, grinder, BBF, nether.)
