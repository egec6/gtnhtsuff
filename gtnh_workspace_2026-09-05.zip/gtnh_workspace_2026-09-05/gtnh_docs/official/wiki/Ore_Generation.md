# Ore Generation (wiki extract)
Source: https://wiki.gtnewhorizons.com/wiki/Ore_Generation
Pulled Sept 1, 2026.

Veins on a grid from chunk (0,0). Off-axis: ore chunk then two empty. On the 0,0 axes: tighter.
Vein is 9 blocks tall. Primary top 4, secondary bottom 4, between layers 3–6, sporadic anywhere.

Prospect: |chunkX| mod 3 = 1 and |chunkZ| mod 3 = 1.
JourneyMap "Show GT Ore Veins" after touching a real ore block (small ores do not register).
XML overlay: "This is an ore chunk."
Ore Finder Wand: 60 down, 3-block radius.

Raw vein ore ≠ small ore. Small ore: stripy, "Small X Ore" in WAILA, fortune works, harvest level one lower than the full block.
Global OW small ores include diamond, redstone, lapis, gold, silver, iron, nickel, copper, zinc, tin, coal.

Silver for solar boilers: small ore OW y20–60, 20/chunk (official small-ore sheet).
Diamond small ore: y5–15, amount 2 — sometimes one harvest level easier than vein diamond.
