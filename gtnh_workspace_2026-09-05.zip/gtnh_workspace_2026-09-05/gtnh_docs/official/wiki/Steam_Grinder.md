# Steam Grinder (wiki extract)
Source: https://wiki.gtnewhorizons.com/wiki/Steam_Grinder
Pulled Sept 1, 2026.

Direct upgrade from the singleblock steam macerator.
125% speed, 62.5% steam, **8 parallels**.
HP version: twice the steam, twice the speed.

Basic T1 cost (hammer plates + file rods): **285 bronze + 21 brick**.
HP T2: 286 steel + 66 bronze + 4 brick.

Recipes up to LV. **No macerator byproducts** — those wait for HV singleblock or IMS.
Lasts toward HV. Then Industrial Maceration Stack (EV).
Wallshare possible.

This run already called it “the GOAT of the tier.” Cost is a steel-age / late-steam project, not tonight’s 2-boiler platform.
