# GT New Horizons Mod Pack

Version 2.9.0-beta-2 is out 2026-07-05

## What is GT New Horizons?

<p align="justify">
    You are looking at a big progressive kitchensink pack for Minecraft 1.7.10 balanced around the mod GregTech.<BR><BR>
    Over 11 years of development (and still going) have formed a balance and refinement that only a handful of packs can keep up with. We are talking about thousands of recipe tweaks, a massive questbook with over 3500 quests, unique world generation, custom mods coded for the pack, custom Thaumonomicon pages, and many more.
    The main intentions of the pack are a long-lasting experience and tying mods together in a progressive fashion, making it feel more like a single game than a compilation of mods thrown together.<BR><BR>
    To reach this goal, GT New Horizons is using the tiers (basically ages of technology) from GregTech and allocates content of other mods to a fitting point within the progression.<BR><BR>
    Starting in the stone age you will barely be able to survive until you get your first steam machines and, eventually, reach electricity. Later on, you will have to visit other planets and dimensions to gather important resources and fight mighty bosses to channel their magical power.<BR><BR>
    If you are a fan of expert mode packs and want to take it to the next level, this pack will be your friend!
</p>

## Our Discord server

Here is our Discord server in case you want to take a look at it:

[![Join the Discord Server](https://discordapp.com/api/guilds/181078474394566657/widget.png?style=banner4)](https://discord.gg/gtnh)

## Installing
 
<p align="justify">
    To install the GTNH modpack, please follow the instructions on the page <a href="http://gtnh.miraheze.org/wiki/Installing_and_Migrating">Installing and Migrating</a>.<BR>
    The installation files can be found on our website <a href="https://www.gtnewhorizons.com/downloads/">gtnewhorizons.com/downloads</a>.<BR>
    Do not download the mods separately from the Modlist below - it is only provided for reference purposes.
</p>

## Thanks

<img src="https://www.yourkit.com/images/yklogo.png">

Thanks to YourKit for providing licenses to open source projects.
YourKit supports open source projects with innovative and intelligent tools
for monitoring and profiling Java and .NET applications.
YourKit is the creator of <a href="https://www.yourkit.com/java/profiler/">YourKit Java Profiler</a>,
<a href="https://www.yourkit.com/dotnet-profiler/">YourKit .NET Profiler</a>,
and <a href="https://www.yourkit.com/youmonitor/">YourKit YouMonitor</a>.

## Quotes
<div align="justify"><ul>
    <li>thcv - This pack is pushing my mental capacity</li>
    <li>moronwmachinegun - Noooooooooooooooo! (after cleanroom explosion)</li>
    <li>mitchej123 - it probably would have been a bit easier if I put the turbines closer, but it wouldn't look as cool</li>
    <li>K1ngMX - problem is like in programming: each change in isolation makes sense, some time later you think "how could this all happen" lol</li>
    <li>tsutaaja - If it's not too costly</li>
    <li>DreamMasterXXL - Idiots! Do not upgrade your backpack with important stuff inside!</li>
    <li>Chaotick - It's already quite the list of errands</li>
    <li>LogicFalls - F--k this mod is complicated</li>
    <li>Codewarrior0 - Blood, sweat, and tiers</li>
    <li>Chewy - No more making any of this irritating s--t</li>
    <li>moronwmachinegun - It's never enough</li>
    <li>Mondfaust - this game wants so much stuff...</li>
    <li>K1ngMX - GTNH is basically pain for win</li>
    <li>Pao - RNGesus hates you.</li>
    <li>LogicFalls - This modpack makes me unhappy. But it's the good kind of unhappy.</li>
    <li>Elusive Ent - GTNH you never fail to frustrate, but i love you all the same</li>
    <li>DoomSquirter - welcome to gregtech where we invented the fountain of youth by slowing down time to make you enjoy each millisecond even more.</li>
    <li>moronwmachinegun - controller on the front, maintenance in the back? World's worst haircut - gregullet</li>
    <li>Axiflare - I've jabbed my screwdriver and my fist into it every way I can think of.</li>
    <li>Scribit - Useless coins that are actually useful.</li>
    <li>StevensMelon - i really hate this pack why wont i stop playing it. wanT  to go back to omifactory where everything was simpler 😭</li>
</ul></div>

## What does this pack have to offer?

***Technology***<BR>

<p align=justify>
    GregTech on its own comes with a huge tech tree using the EU system and the other technology-based mods will open up while you are progressing through the tiers.<BR>
    <BR>
    The main cables of GregTech convert EU to RF so you don't have to worry about different energy systems and things feeling incompatible.<BR>
    <BR>
    Complex processing lines, automation, a large variety in power generation and a lot of materials to work with create an environment with many possibilities that the player has to explore.<BR>
    <BR>
    Crossbreeding plants, bees and crops with Forestry and IndustrialCraft2, setting up mob farms using EnderIO and Draconic Evolution, and general infrastructure improvements with Railcraft and Applied Energistics - it's all there, anything you want (and need!) if you enjoy the technical aspect of modded Minecraft.
</p>

***Magic***<BR> 

<p align="justify">
    GT New Horizons comes with a variety of powerful magic mods. Your main access will be through the Thauminomicon which is modified to also feature custom sections for Botania, Blood Magic, Witchery, and other important things besides having the usual content of Thaumcraft and its add-ons.<BR>
    <BR>
    The Twilight Forest is the dimension linked to magic in this pack and you will have to explore and defeat the bosses to progress in magic. Later on, there is power generation with essentia and options to store it using your AE system connecting technology with magic.
</p>

***Exploration***<BR>

<p align="justify">
    Using Realistic World Gen along with Biomes O' Plenty creates a beautiful terrain in the overworld.<BR>
    <BR>
    Besides all the biomes and natural structures you can find there will be challenging Rogue-like Dungeons that come with decent loot and spawners you might want to use in creative ways.<BR>
    <BR>
    In the early game, villages offer a nice resting spot while looking for the optimal base location. Later you will revisit the villages to trade for key items and scavenge for parts. Eventually, you may end up relocating villagers closer to you - or taking over a village yourself.
</p>

***Put the mining back in Minecraft*** <BR>

<p align="justify"> 
    GregTech spawns ore in large localized veins rather than small clusters of everything, rewarding long searches with a huge vein that can sustain your base's growth for a long time.<BR>
    <BR>
    In most packs, nearly everything spawns in the overworld which is not the case in GT New Horizons, and you are encouraged to mine in other dimensions such as the Twilight Forest, the nether, the end and (later on) even on other planets to make your way to the endgame. Unlocking things by mining for materials on other planets will create that situation where Galacticraft all of a sudden becomes important to progress which feels really rewarding.<BR>
</p>

***Survival***<BR>

<p align="justify">
    The first few days and nights will be rough, in fact, nights will stay rough for a while since hardcore darkness makes them pitch black without any light sources or potion effects, so you might want to get a bed quickly!<BR>
    <BR>
    Food is a critical thing early game and you can't keep eating the same things because of Spice of Life. Better watch out for some gardens from Pam's Harvestcraft to get some variety into your nutrition!<BR>
    <BR>
    Be prepared to face strong mobs that can cause death quickly if you play without any strategy.<BR>
    <BR>
    Facing them with better gear will make life easier once you progress but until then light up your base - there are plenty of options available from Chisel, Project Red, Ztones and Floodlights.<BR>
</p>

***Questing***<BR>
<p align="justify">
    GT New Horizons comes with over 3500+ quests that will guide the player through the maze that modded Minecraft can be.<BR>
    <BR>
    The texts will inform you what's required to progress so you don't have to watch tutorials or ask others as often. The questbook can even save you the time to type into NEI, just click the items displayed in the quest and it will display the recipe through NEI, quite handy, right?<BR>
    <BR>
    Custom lootbags and the coin system make for unique and helpful rewards. And we all enjoy the gamble from time to time.
</p>

***Is this a game for newbies?***<BR>

<p align="justify">
    Newbies to Minecraft? Definitely not. Newbies to modded Minecraft?  Maybe.  The questbook is a great introduction to the variety and type of mods available. With each mod, gated players must learn about the mod to make the most of it while waiting for the next mod to unlock.
</p>

***Is this modpack for me?***<BR>

<p align="justify">
    Does the thought of earning that top-end gear over weeks or months appeal to you? The usual packs feel like they are over in 1 or 2 weeks since you get OP gear so quickly?<BR>
    <BR>
    How about designing a chemical processing system to rival a real oil refinery, with multiple inputs creating dozens of outputs and intermediate products to finally make a bar of plastic, rubber, explosives or other top-end gear?<BR>
    <BR>
    Does the sound of machinery processing ore via crushing, washing, centrifuging, smelting in a blast furnace, and cooling off in a vacuum freezer tickle your brain?<BR>
    <BR>
    Then this is the pack for you.<BR>
    <BR>
    Your pick is not ready.<BR>
    <BR>
    Welcome home.<BR>
</p>

---
## How to join a server

<p align="justify">
    Go to the multiplayer menu and choose the server you would like to play on. If the server is whitelisted (check out the list below) you have to contact the staff on the linked website/discord first. For the official servers you can either apply directly on our website or type the "!apply" command on our discord (both linked below) to get further instructions on how to join! 
</p>

### EU Servers:<BR>

Official EU Server Public (whitelist)<BR>
https://www.gtnewhorizons.com/ <BR>
delta.gtnewhorizons.com<BR>
epsilon.gtnewhorizons.com<BR>
eta.gtnewhorizons.com<BR>

Official EU Test Server(whitelist)<BR>

For experimentals:<BR>
zeta.gtnewhorizons.com<BR>

For dailies:<BR>
iota.gtnewhorizons.com<BR>

Modded Minecraft Club Falkenstein, Germany (open)<BR>
https://www.moddedminecraft.club/ <BR>
gtnh.moddedminecraft.club (Teleport enabled)<BR>
gtnh-im.moddedminecraft.club (Ironman, no teleport)<BR>

MineYourMine<BR>
MineYourMine GTNH (EU) horizons.mineyourmind.net<BR>

Zephyrus<BR>
Zephyrus (NL) gtnh.zephyrus-mc.com<BR>

Arcturus Network Czech Republic (EU)<BR>
Discord: https://discord.gg/JCCY9NR <BR>
Wiki: http://wiki.arcturus-official.eu/ <BR>
play.arcturus-official.eu<BR>


### US/Canada Servers:<BR>

Apocalyptic Gaming Network<BR>
IP: GTNH.APOCGAMING.ORG<BR>
SITE: https://apocgaming.org<BR>
DISCORD: https://apocgaming.org/discord<BR>

Prospercraft (greylist)<BR>
http://www.prospercraft.com/ <BR>
newhorizonsold.prospercraft.com<BR>
newhorizons.prospercraft.com<BR>

StoneLegion <BR>
StoneLegion.com GTNH (Canada) mc.stonelegion.com<BR>

Earthquake<BR>
Earthquake GTNH (US West) aragil.ddns.net<BR>
	
	
Modded Minecraft Club(open)<BR>
(same server as above)<BR>
Modded Minecraft Club  (Eu-Asia) gtnh.moddedminecraft.club<BR>
Modded Minecraft Club (Am+Aus) gtnh-na.moddedminecraft.club<BR>
MMC No TP (Eu+Asia2) gtnh-im.moddedminecraft.club<BR>
MMC No TP (Am+Aus2) gtnh-im-na.moddedminecraft.club<BR>

Stone Huts EU Server (whitelist)<BR>
IP: gtnh.stonehuts.net<BR>
http://stonehuts.net <BR>


### German Server:<BR>

MyFTB Public (open)<BR>
https://myftb.de/ <BR>
gtnewhorizons.myftb.de<BR>



### Russian Servers:<BR>

Hitechmine.ru  GTNG Server Russia<BR>
hitechmine.ru:25565

Zvezdolet New fresh Russian server Whitelisted<BR>
IP: gtnh.114-7.com
  


## Official Links

Prism / MultiMC Downloads: https://www.gtnewhorizons.com/downloads/ <BR>
Technic Launcher Link: https://www.technicpack.net/modpack/mcnewhorizons.677387 <BR>
Curse Link: https://minecraft.curseforge.com/projects/gt-new-horizons <BR>
Discord Link: https://discord.gg/gtnh <BR>
Website Link: https://www.gtnewhorizons.com/ <BR>
Wiki Link: https://wiki.gtnewhorizons.com/wiki/Main_Page<BR>

### Contributing

Want to contribute to GTNH? Join our Discord with the link above and read the development manual: https://wiki.gtnewhorizons.com/wiki/Development.



## Resource Realistic Sky GT New Horizons
A resource pack created by MajaProduction that needs Optifine installed, you can find it in your resource folder<BR>

---
## Modlist - NewHorizons
 
Downloads can be found at https://www.gtnewhorizons.com/downloads/ - do not try to download and install using the links below, this is for reference.

| Name | Version |
| --- | --- |
| [Advanced Solar Panel For 1.7.10 (Unofficial)](https://www.curseforge.com/minecraft/mc-mods/advancedsolarpanels) | 1.7.10 Edition |
| [AdventureBackpack2](https://github.com/GTNewHorizons/AdventureBackpack2) | 1.4.22-GTNH |
| [AE2FluidCraft-Rework](https://github.com/GTNewHorizons/AE2FluidCraft-Rework) | 1.5.95-gtnh |
| [AFSU](https://github.com/GTNewHorizons/AFSU) | 1.3.2-GTNH |
| [AkashicTome](https://github.com/GTNewHorizons/AkashicTome) | 1.2.7 |
| [AlchemyGrate](https://github.com/GTNewHorizons/AlchemyGrate) | 1.3.2-GTNH |
| [Amazing-Trophies](https://github.com/GTNewHorizons/Amazing-Trophies) | 1.4.3 |
| [amunra](https://github.com/GTNewHorizons/amunra) | 0.8.13 |
| [Angelica](https://github.com/GTNewHorizons/Angelica) | 2.1.50 |
| [AngerMod](https://github.com/GTNewHorizons/AngerMod) | 1.0.7 |
| [AppleCore](https://github.com/GTNewHorizons/AppleCore) | 3.3.11 |
| [Applied-Energistics-2-Unofficial](https://github.com/GTNewHorizons/Applied-Energistics-2-Unofficial) | rv3-beta-1000-GTNH |
| [Archaicfix](https://github.com/embeddedt/ArchaicFix) | 0.8.0 |
| [ArchitectureCraft](https://github.com/GTNewHorizons/ArchitectureCraft) | 1.12.14 |
| [AsieLib](https://github.com/GTNewHorizons/AsieLib) | 0.7.2 |
| [AspectRecipeIndex](https://github.com/GTNewHorizons/AspectRecipeIndex) | 1.1.3 |
| [Automagy](https://www.curseforge.com/minecraft/mc-mods/automagy) | 0.28.2 |
| [Avaritia](https://github.com/GTNewHorizons/Avaritia) | 1.97 |
| [Avaritiaddons](https://github.com/GTNewHorizons/Avaritiaddons) | 1.9.4-GTNH |
| [Backhand](https://github.com/GTNewHorizons/Backhand) | 1.8.11 |
| [Battlegear2-for-Backhand](https://github.com/GTNewHorizons/Battlegear2-for-Backhand) | 1.6.8-backhand |
| [Baubles-Expanded](https://github.com/GTNewHorizons/Baubles-Expanded) | 2.2.21-GTNH |
| [bdlib](https://github.com/GTNewHorizons/bdlib) | 1.11.0-GTNH |
| [BeeBetterAtBees-GTNH](https://github.com/GTNewHorizons/BeeBetterAtBees-GTNH) | 0.4.6-GTNH |
| [BetterAchievements](https://github.com/GTNewHorizons/BetterAchievements) | 0.3.3 |
| [BetterBuildersWands](https://github.com/GTNewHorizons/BetterBuildersWands) | 0.13.11-GTNH |
| [BetterCrashes](https://github.com/GTNewHorizons/BetterCrashes) | 1.4.5-GTNH |
| [BetterLoadingScreen](https://github.com/GTNewHorizons/BetterLoadingScreen) | 1.7.9-GTNH |
| [BetterP2P](https://github.com/GTNewHorizons/BetterP2P) | 1.4.5 |
| [BetterQuesting](https://github.com/GTNewHorizons/BetterQuesting) | 3.8.72-GTNH |
| [BiblioCraft: BiblioWoods Biomes O'Plenty Edition](https://www.curseforge.com/minecraft/mc-mods/bibliocraft-bibliowoods-biomes-oplenty-edition) | 1.9 |
| [BiblioCraft: BiblioWoods Forestry Edition](https://www.curseforge.com/minecraft/mc-mods/bibliocraft-bibliowoods-forestry-edition) | 1.7 |
| [BiblioCraft: BiblioWoods Natura Edition](https://www.curseforge.com/minecraft/mc-mods/bibliocraft-bibliowoods-natura-edition) | 1.5 |
| [BiblioCraft](https://www.curseforge.com/minecraft/mc-mods/bibliocraft) | 1.11.7 |
| [Binnie](https://github.com/GTNewHorizons/Binnie) | 2.6.34 |
| [Biomes O' Plenty](https://www.curseforge.com/minecraft/mc-mods/biomes-o-plenty) | 2.1.0.2308 |
| [BlockLimiter](https://github.com/GTNewHorizons/BlockLimiter) | 0.7.0 |
| [BlockRenderer6343](https://github.com/GTNewHorizons/BlockRenderer6343) | 1.4.17 |
| [BloodArsenal](https://github.com/GTNewHorizons/BloodArsenal) | 1.5.11 |
| [BloodMagic](https://github.com/GTNewHorizons/BloodMagic) | 1.9.4 |
| [Botania](https://github.com/GTNewHorizons/Botania) | 1.13.26-GTNH |
| [Botanic-horizons](https://github.com/GTNewHorizons/Botanic-horizons) | 1.12.10-GTNH |
| [Bug-Torch](https://github.com/jss2a98aj/BugTorch) | 1.2.14 |
| [BuildCraft](https://github.com/GTNewHorizons/BuildCraft) | 7.1.61 |
| [BuildCraftCompat](https://github.com/GTNewHorizons/BuildCraftCompat) | 7.1.21 |
| [BuildCraftOilTweak](https://github.com/GTNewHorizons/BuildCraftOilTweak) | 1.1.3 |
| [CarpentersBlocks](https://github.com/GTNewHorizons/CarpentersBlocks) | 3.7.3-GTNH |
| [Catwalks-2](https://github.com/GTNewHorizons/Catwalks-2) | 2.4.1-GTNH |
| [Chisel](https://github.com/GTNewHorizons/Chisel) | 2.17.28-GTNH |
| [ChiselTones](https://github.com/GTNewHorizons/ChiselTones) | 1.2.0-GTNH |
| [ChromaticTooltips](https://github.com/GTNewHorizons/ChromaticTooltips) | 1.0.29-GTNH |
| [ChromaticTooltipsCompat](https://github.com/GTNewHorizons/ChromaticTooltipsCompat) | 1.0.33-GTNH |
| [Chunk API](https://www.curseforge.com/minecraft/mc-mods/chunkapi/) | 0.8.3 |
| [CodeChickenCore](https://github.com/GTNewHorizons/CodeChickenCore) | 1.4.16 |
| [CoFH Core](https://www.curseforge.com/minecraft/mc-mods/cofh-core) | 3.1.4-329 |
| [Compact Kinetic Generators](https://forum.industrial-craft.net/thread/12724-ic2-exp-1-7-10-compact-kinetic-generators/) | 1.0 |
| [Computronics](https://github.com/GTNewHorizons/Computronics) | 1.9.8-GTNH |
| [Controlling](https://github.com/GTNewHorizons/Controlling) | 2.1.7 |
| [CookingForBlockheads](https://github.com/GTNewHorizons/CookingForBlockheads) | 1.4.12-GTNH |
| [CoreTweaks](https://github.com/GTNewHorizons/CoreTweaks) | 0.3.4.7-GTNH |
| [CosmeticArmorReworked](https://github.com/GTNewHorizons/CosmeticArmorReworked) | 1.0.6-GTNH |
| [Craft-Presence](https://www.curseforge.com/minecraft/mc-mods/craftpresence/) | 2.7.1 |
| [CraftTweaker](https://github.com/GTNewHorizons/CraftTweaker) | 3.4.7 |
| [CropsNH](https://github.com/GTNewHorizons/CropsNH) | 2.0.91 |
| [Custom-Main-Menu](https://github.com/GTNewHorizons/Custom-Main-Menu) | 1.14.1 |
| [Darkerer](https://github.com/GTNewHorizons/Darkerer) | 1.1.0 |
| [Default-Configs](https://github.com/GTNewHorizons/Default-Configs) | 1.3.1 |
| [DefaultServerList](https://github.com/GTNewHorizons/DefaultServerList) | 1.7.4 |
| [DefaultWorldGenerator](https://github.com/GTNewHorizons/DefaultWorldGenerator) | 0.4.0 |
| [Draconic-Evolution](https://github.com/GTNewHorizons/Draconic-Evolution) | 1.5.27-GTNH |
| [DummyCore](https://github.com/GTNewHorizons/DummyCore) | 1.21.0 |
| [DuraDisplay](https://github.com/GTNewHorizons/DuraDisplay) | 1.4.4 |
| [Electro-Magic-Tools](https://github.com/GTNewHorizons/Electro-Magic-Tools) | 1.7.24 |
| [EnderCore](https://github.com/GTNewHorizons/EnderCore) | 0.5.14 |
| [EnderIO](https://github.com/GTNewHorizons/EnderIO) | 2.10.32 |
| [EnderStorage](https://github.com/GTNewHorizons/EnderStorage) | 1.8.3 |
| [EnderZoo](https://github.com/GTNewHorizons/EnderZoo) | 1.3.5 |
| [EndlessIDs](https://www.curseforge.com/minecraft/mc-mods/endlessids/) | 1.7.4 |
| [EnhancedLootBags](https://github.com/GTNewHorizons/EnhancedLootBags) | 1.3.4 |
| [Et-Futurum-Requiem](https://github.com/GTNewHorizons/Et-Futurum-Requiem) | 2.6.48-GTNH |
| [Eternal-Singularity](https://github.com/GTNewHorizons/Eternal-Singularity) | 1.4.3 |
| [Extra Utilities](https://www.curseforge.com/minecraft/mc-mods/extra-utilities) | 1.2.12 |
| [Extreme Sound Muffler](https://www.curseforge.com/minecraft/mc-mods/extreme-sound-muffler-legacy) | 1.1.0 |
| [FalsepatternLib](https://www.curseforge.com/minecraft/mc-mods/fplib) | 1.12.2 |
| [Fether](https://github.com/GTNewHorizons/Fether) | 2.0.5 |
| [FindIt](https://github.com/GTNewHorizons/FindIt) | 1.4.3 |
| [FloodLights](https://github.com/GTNewHorizons/FloodLights) | 1.5.6 |
| [ForbiddenMagic](https://github.com/GTNewHorizons/ForbiddenMagic) | 0.9.16-GTNH |
| [ForestryMC](https://github.com/GTNewHorizons/ForestryMC) | 4.11.31 |
| [Forgelin](https://github.com/GTNewHorizons/Forgelin) | 2.0.3-GTNH |
| [ForgeMultipart](https://github.com/GTNewHorizons/ForgeMultipart) | 1.7.10 |
| [ForgeRelocation](https://github.com/GTNewHorizons/ForgeRelocation) | 0.3.6 |
| [ForgeRelocationFMP](https://github.com/GTNewHorizons/ForgeRelocationFMP) | 0.2.0 |
| [Freecam](https://github.com/GTNewHorizons/Freecam) | 1.0.9 |
| [Gadomancy](https://github.com/GTNewHorizons/Gadomancy) | 1.5.12 |
| [Galacticraft](https://github.com/GTNewHorizons/Galacticraft) | 3.4.31-GTNH |
| [Galaxy-Space-GTNH](https://github.com/GTNewHorizons/Galaxy-Space-GTNH) | 1.1.139-GTNH |
| [gendustry](https://github.com/GTNewHorizons/gendustry) | 1.9.11-GTNH |
| [Gravitation-Suite-Neo](https://github.com/GTNewHorizons/Gravitation-Suite-Neo) | 1.3.12 |
| [Gravitation-Suite-old](https://forum.industrial-craft.net/thread/6915-ic2-exp-1-7-10-gravitation-suite-v2-0-3/) | 2.0.3 |
| [GregoryTweaksForCrafting](https://github.com/GTNewHorizons/GregoryTweaksForCrafting) | 1.0.3 |
| [GT5-Unofficial](https://github.com/GTNewHorizons/GT5-Unofficial) | 5.09.54.20 |
| [GTNH-Credits](https://github.com/GTNewHorizons/GTNH-Credits) | 1.3.1 |
| [GTNH-TC-Wands](https://github.com/GTNewHorizons/GTNH-TC-Wands) | 1.4.14 |
| [GTNHExtLib](https://github.com/GTNewHorizons/GTNHExtLib) | 1.0.3 |
| [GTNHLib](https://github.com/GTNewHorizons/GTNHLib) | 0.11.24 |
| [GuideNH](https://github.com/GTNewHorizons/GuideNH) | 1.3.11 |
| [Hardcore-Ender-Expansion](https://github.com/GTNewHorizons/Hardcore-Ender-Expansion) | 1.12.25-GTNH |
| [harvestcraft](https://github.com/GTNewHorizons/harvestcraft) | 1.3.11-GTNH |
| [Healer](https://www.curseforge.com/minecraft/mc-mods/healer) | 1.2.1 |
| [HelpFixer](https://github.com/GTNewHorizons/HelpFixer) | 1.3.1 |
| [Hodgepodge](https://github.com/GTNewHorizons/Hodgepodge) | 2.7.170 |
| [HoloInventory](https://github.com/GTNewHorizons/HoloInventory) | 2.5.15-GTNH |
| [Hunger-Overhaul](https://www.curseforge.com/minecraft/mc-mods/hunger-overhaul) | 1.0.0.104 |
| [HydroEnergy](https://github.com/GTNewHorizons/HydroEnergy) | 1.4.21 |
| [IFU](https://github.com/GTNewHorizons/IFU) | 1.12.2 |
| [IguanaTweaksTConstruct](https://github.com/GTNewHorizons/IguanaTweaksTConstruct) | 2.7.10 |
| [Industrial Craft 2](https://www.curseforge.com/minecraft/mc-mods/industrial-craft) | 2.2.2.828 |
| [Infernal-Mobs](https://github.com/GTNewHorizons/Infernal-Mobs) | 1.10.5-GTNH |
| [InGame-Info-XML](https://github.com/GTNewHorizons/InGame-Info-XML) | 2.9.3 |
| [InventoryBogoSorter](https://github.com/GTNewHorizons/InventoryBogoSorter) | 1.3.37-GTNH |
| [ironchest](https://github.com/GTNewHorizons/ironchest) | 6.1.13 |
| [IronChestMinecarts](https://github.com/GTNewHorizons/IronChestMinecarts) | 1.2.1 |
| [IronTankMinecarts](https://github.com/GTNewHorizons/IronTankMinecarts) | 1.0.12 |
| [Irontanks](https://github.com/GTNewHorizons/Irontanks) | 1.4.7 |
| [Jabba](https://github.com/GTNewHorizons/Jabba) | 1.5.20 |
| [JarJar](https://github.com/GTNewHorizons/JarJar) | 0.3.7-beta |
| [JourneyMap Server](https://www.curseforge.com/minecraft/mc-mods/journeymap-server) | 1.0.5 |
| [JourneyMap](https://www.curseforge.com/minecraft/mc-mods/journeymap) | 5.2.19-fairplay |
| [LittleTiles](https://github.com/GTNewHorizons/LittleTiles) | 1.6.30 |
| [LogisticsPipes](https://github.com/GTNewHorizons/LogisticsPipes) | 1.5.28-GTNH |
| [LootGames](https://github.com/GTNewHorizons/LootGames) | 2.2.13 |
| [LunatriusCore](https://github.com/GTNewHorizons/LunatriusCore) | 1.2.1-GTNH |
| [lwjgl3ify](https://github.com/GTNewHorizons/lwjgl3ify) | 3.0.26 |
| [MagicBees](https://github.com/GTNewHorizons/MagicBees) | 2.10.9-GTNH |
| [MalisisDoors](https://github.com/GTNewHorizons/MalisisDoors) | 1.19.8-GTNH |
| [Mantle](https://github.com/GTNewHorizons/Mantle) | 0.5.4 |
| [MatterManipulator](https://github.com/GTNewHorizons/MatterManipulator) | 0.1.46-GTNH |
| [Minecraft-Backpack-Mod](https://github.com/GTNewHorizons/Minecraft-Backpack-Mod) | 2.6.13-GTNH |
| [Minetweaker-Gregtech-5-Addon](https://github.com/GTNewHorizons/Minetweaker-Gregtech-5-Addon) | 2.3.3 |
| [Mobs-Info](https://github.com/GTNewHorizons/Mobs-Info) | 0.5.18-GTNH |
| [ModernMarkings](https://github.com/GTNewHorizons/ModernMarkings) | 0.3.13-1.7.10 |
| [ModTweaker](https://github.com/GTNewHorizons/ModTweaker) | 0.13.0 |
| [ModularUI2](https://github.com/GTNewHorizons/ModularUI2) | 2.3.79-1.7.10 |
| [ModularUI](https://github.com/GTNewHorizons/ModularUI) | 1.3.4 |
| [MouseTweaks](https://github.com/GTNewHorizons/MouseTweaks) | 2.5.2-GTNH |
| [MrTJPCore](https://github.com/GTNewHorizons/MrTJPCore) | 1.3.7 |
| [Natura](https://github.com/GTNewHorizons/Natura) | 2.8.20 |
| [NaturesCompass](https://github.com/GTNewHorizons/NaturesCompass) | 1.5.2-GTNH |
| [Navigator](https://github.com/GTNewHorizons/Navigator) | 1.1.4 |
| [nei-custom-diagram](https://github.com/GTNewHorizons/nei-custom-diagram) | 1.8.30 |
| [NEI-Integration](https://github.com/GTNewHorizons/NEI-Integration) | 1.5.3 |
| [neiaddons](https://github.com/GTNewHorizons/neiaddons) | 1.18.2 |
| [NetherPortalFix](https://github.com/GTNewHorizons/NetherPortalFix) | 1.4.0 |
| [NewHorizonsCoreMod](https://github.com/GTNewHorizons/NewHorizonsCoreMod) | 2.9.5 |
| [Nodal-Mechanics](https://github.com/GTNewHorizons/Nodal-Mechanics) | 1.3.4-GTNH |
| [NoHotbarNeeded](https://github.com/GTNewHorizons/NoHotbarNeeded) | 0.0.5 |
| [NotEnoughEnergistics](https://github.com/GTNewHorizons/NotEnoughEnergistics) | 1.7.34 |
| [NotEnoughItems](https://github.com/GTNewHorizons/NotEnoughItems) | 2.8.111-GTNH |
| [Nuclear-Control](https://github.com/GTNewHorizons/Nuclear-Control) | 2.7.10 |
| [Nutrition](https://github.com/GTNewHorizons/Nutrition) | 0.1.9 |
| [oauth](https://github.com/GTNewHorizons/oauth) | 1.3.4-GTNH |
| [OCGlasses](https://github.com/GTNewHorizons/OCGlasses) | 1.6.7-GTNH |
| [OpenBlocks](https://github.com/GTNewHorizons/OpenBlocks) | 1.12.18-GTNH |
| [OpenComputers](https://github.com/GTNewHorizons/OpenComputers) | 1.12.48-GTNH |
| [OpenModsLib](https://github.com/GTNewHorizons/OpenModsLib) | 0.10.14 |
| [OpenModularTurrets](https://github.com/GTNewHorizons/OpenModularTurrets) | 2.4.5 |
| [OpenPrinter](https://github.com/GTNewHorizons/OpenPrinter) | 0.3.1-GTNH |
| [OpenSecurity](https://github.com/GTNewHorizons/OpenSecurity) | 1.2.2-GTNH |
| [Opis](https://github.com/GTNewHorizons/Opis) | 1.4.8-mapless |
| [OverloadedArmorBar](https://github.com/GTNewHorizons/OverloadedArmorBar) | 1.1.1 |
| [PersonalSpace](https://github.com/GTNewHorizons/PersonalSpace) | 1.0.40 |
| [Player-API](https://github.com/GTNewHorizons/Player-API) | 1.5.0 |
| [Postea](https://github.com/GTNewHorizons/Postea) | 1.2.5 |
| [ProjectBlue](https://github.com/GTNewHorizons/ProjectBlue) | 1.2.10-GTNH |
| [ProjectRed](https://github.com/GTNewHorizons/ProjectRed) | 4.12.39-GTNH |
| [Railcraft](https://github.com/GTNewHorizons/Railcraft) | 9.17.29 |
| [Random-Things](https://github.com/GTNewHorizons/Random-Things) | 2.7.8 |
| [RandomBoubles](https://github.com/GTNewHorizons/RandomBoubles) | 1.1.6 |
| [Realistic-World-Gen](https://github.com/GTNewHorizons/Realistic-World-Gen) | alpha-1.5.2 |
| [RemoteIO](https://github.com/GTNewHorizons/RemoteIO) | 2.7.10 |
| [Roguelike-Dungeons](https://github.com/GTNewHorizons/Roguelike-Dungeons) | 1.6.6-GTNH |
| [Salis-Arcana](https://github.com/GTNewHorizons/Salis-Arcana) | 1.1.65-GTNH |
| [SC2](https://github.com/GTNewHorizons/SC2) | 2.3.14 |
| [Schematica](https://github.com/GTNewHorizons/Schematica) | 1.12.6-GTNH |
| [ServerUtilities](https://github.com/GTNewHorizons/ServerUtilities) | 2.4.1 |
| [SGCraft](https://github.com/GTNewHorizons/SGCraft) | 1.4.13-GTNH |
| [Share-Where-I-am](https://github.com/GTNewHorizons/Share-Where-I-am) | 2.1.7 |
| [SimpleSkinBackport](https://github.com/GTNewHorizons/SimpleSkinBackport) | 1.0.2-GTNH |
| [SleepingBags](https://github.com/GTNewHorizons/SleepingBags) | 0.3.1 |
| [SpecialMobs](https://github.com/GTNewHorizons/SpecialMobs) | 3.7.4 |
| [SpiceOfLife](https://github.com/GTNewHorizons/SpiceOfLife) | 2.2.10-carrot |
| [Steve-s-Factory-Manager](https://github.com/GTNewHorizons/Steve-s-Factory-Manager) | 1.3.12-GTNH |
| [StevesAddons](https://github.com/GTNewHorizons/StevesAddons) | 0.15.5 |
| [StorageDrawers](https://github.com/GTNewHorizons/StorageDrawers) | 2.2.26-GTNH |
| [StructureCompat](https://github.com/GTNewHorizons/StructureCompat) | 0.7.4 |
| [StructureLib](https://github.com/GTNewHorizons/StructureLib) | 1.4.42 |
| [Super-TiC](https://github.com/GTNewHorizons/Super-TiC) | 1.5.4 |
| [supersolarpanels](https://github.com/GTNewHorizons/supersolarpanels) | 1.1.5 |
| [Tainted-Magic](https://github.com/GTNewHorizons/Tainted-Magic) | 7.7.8-GTNH |
| [TC-4-Tweaks](https://www.curseforge.com/minecraft/mc-mods/tc4tweaks) | 1.5.45 |
| [TCNodeTracker](https://github.com/GTNewHorizons/TCNodeTracker) | 1.4.5 |
| [thaumcraft-research-tweaks](https://github.com/GTNewHorizons/thaumcraft-research-tweaks) | 1.4.0 |
| [Thaumcraft](https://www.curseforge.com/minecraft/mc-mods/thaumcraft) | 4.2.3.5 |
| [ThaumcraftMobAspects](https://github.com/GTNewHorizons/ThaumcraftMobAspects) | 1.2.1-GTNH |
| [Thaumic_Exploration](https://github.com/GTNewHorizons/Thaumic_Exploration) | 1.5.24-GTNH |
| [ThaumicBases](https://github.com/GTNewHorizons/ThaumicBases) | 1.9.18 |
| [ThaumicBoots](https://github.com/GTNewHorizons/ThaumicBoots) | 1.5.12 |
| [ThaumicEnergistics](https://github.com/GTNewHorizons/ThaumicEnergistics) | 1.7.56-GTNH |
| [ThaumicHorizons](https://github.com/GTNewHorizons/ThaumicHorizons) | 1.8.20 |
| [thaumicinsurgence](https://github.com/GTNewHorizons/thaumicinsurgence) | 0.4.1 |
| [ThaumicMachina](https://github.com/GTNewHorizons/ThaumicMachina) | 0.2.5-GTNH |
| [ThaumicTinkerer](https://github.com/GTNewHorizons/ThaumicTinkerer) | 2.12.27 |
| [TiC-Tooltips](https://github.com/GTNewHorizons/TiC-Tooltips) | 1.4.1 |
| [Tinkers-Defense](https://github.com/GTNewHorizons/Tinkers-Defense) | 1.3.4 |
| [Tinkers-Gregworks](https://github.com/Vexatos/TinkersGregworks/tree/GT-NH) | 1.0.33 |
| [TinkersConstruct](https://github.com/GTNewHorizons/TinkersConstruct) | 1.14.93-GTNH |
| [TinkersMechworks](https://github.com/GTNewHorizons/TinkersMechworks) | 0.4.2 |
| [TooMuchLoot](https://github.com/GTNewHorizons/TooMuchLoot) | 4.3.0-GTNH |
| [ToroHealth](https://github.com/GTNewHorizons/ToroHealth) | 1.2.2 |
| [Translocators](https://github.com/GTNewHorizons/Translocators) | 1.4.4 |
| [twilightforest](https://github.com/GTNewHorizons/twilightforest) | 2.7.36 |
| [TX-Loader](https://github.com/GTNewHorizons/TX-Loader) | 1.8.11 |
| [UniLib](https://legacy.curseforge.com/minecraft/mc-mods/unilib) | 1.2.1 |
| [UniMixins](https://github.com/LegacyModdingMC/UniMixins) | 0.3.1 |
| [Universal-Singularities](https://github.com/GTNewHorizons/Universal-Singularities) | 8.15.3 |
| [VendingMachine](https://github.com/GTNewHorizons/VendingMachine) | 0.4.95 |
| [VillageNames](https://github.com/GTNewHorizons/VillageNames) | 4.5.17-GTNH |
| [VisualProspecting](https://github.com/GTNewHorizons/VisualProspecting) | 1.5.33 |
| [waila](https://github.com/GTNewHorizons/waila) | 1.19.30 |
| [WailaHarvestability](https://github.com/GTNewHorizons/WailaHarvestability) | 1.3.6-GTNH |
| [WAILAPlugins](https://github.com/GTNewHorizons/WAILAPlugins) | 0.7.2 |
| [WanionLib](https://github.com/GTNewHorizons/WanionLib) | 1.10.1 |
| [WarpTheory](https://github.com/GTNewHorizons/WarpTheory) | 1.5.7-GTNH |
| [WAWLA](https://github.com/GTNewHorizons/WAWLA) | 1.3.3-GTNH |
| [WirelessCraftingTerminal](https://github.com/GTNewHorizons/WirelessCraftingTerminal) | 1.12.16 |
| [WirelessRedstone-CBE](https://github.com/GTNewHorizons/WirelessRedstone-CBE) | 1.7.6 |
| [Witchery](https://www.curseforge.com/minecraft/mc-mods/witchery) | 0.24.1 |
| [WitcheryExtras](https://github.com/GTNewHorizons/WitcheryExtras) | 1.4.16 |
| [WitchingGadgets](https://github.com/GTNewHorizons/WitchingGadgets) | 1.8.48-GTNH |
| [Yamcl](https://github.com/GTNewHorizons/Yamcl) | 0.7.5 |
| [Ztones](https://www.curseforge.com/minecraft/mc-mods/ztones) | 2.2.2 |

---

Maintained by Dream-MasterXXL, Namikon, Drobac, Teteros, Tec, Lefty, Arnab, Methes, Warlord Wossman, SanMan911, Bigbass1997, Ugachaga, MineAnPlay, Giovanni_NL, Ethryan, MTesseracT, Bryfer, Bartimaeusnek, codewarrior, Moronwmachinegun, Mitchej, Zoko061602, Spartak, Highbeam, 0lafe, Teirdalin, Prometheus, KiloJoel, Glease, Kiwi, Bot, LeaGris, Boubou, Glowredman, Repo, DvDManDT, Moller, Colen, Minecraft7771, MuXiu1997, Runakai, YannickMG, SinTh0r4s, Alexdoru, Kiwi, bombcar, vlaetansky, POPlol333, Raven, miozune, GlodBlock, asdflj, D-Cysteine, DianeXD, BlueWeabo, Kuba, Quarri, Steelux8, S4mpsa, chochem, iouter, Elisis and many more.
